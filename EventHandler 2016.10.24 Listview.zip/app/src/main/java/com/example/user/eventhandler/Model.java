package com.example.user.eventhandler;

/**
 * Created by User on 2016-10-20.
 */

public class Model {
    public String a;
    public String b;
}
