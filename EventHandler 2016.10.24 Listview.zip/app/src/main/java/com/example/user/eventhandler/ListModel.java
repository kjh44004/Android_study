package com.example.user.eventhandler;

/**
 * Created by User on 2016-10-21.
 */

public class ListModel {
    String[] list;
}
