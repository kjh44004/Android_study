package com.example.user.eventhandler.test;

/**
 * Created by User on 2016-10-19.
 */

public class TestClass {
    public void test() {

    }
    private void test2() {

    }

    protected void test1() {

    }
}
