package com.example.user.eventhandler;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

/**
 * Created by User on 2016-10-24.
 */

public class MyListViewAdapter extends BaseAdapter {
    private Activity activity;
    private String[] list;
    private final LayoutInflater layoutInflater;

    public MyListViewAdapter(Activity activity, String[] list) {
        this.activity = activity;
        Context applicationContext = activity.getApplicationContext();
        layoutInflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        this.list = list;
    }

    @Override
    public int getCount() {
        return list.length;
    }

    @Override
    public Object getItem(int position) {
        return list[position];
    }

    @Override
    public long getItemId(int position) {
        return list[position].hashCode();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null) {
            convertView = layoutInflater.inflate(R.layout.listview_row, null);
            MyViewHolder holder = new MyViewHolder();
            holder.textView = (TextView) convertView.findViewById(R.id.textView);
            convertView.setTag(holder);
        }
        MyViewHolder holder = (MyViewHolder) convertView.getTag();
        holder.textView.setText(list[position]);

        return convertView;
    }

    private class MyViewHolder {
        public TextView textView;
    }
}
