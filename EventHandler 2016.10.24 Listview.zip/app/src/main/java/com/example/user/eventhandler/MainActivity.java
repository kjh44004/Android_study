package com.example.user.eventhandler;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements ApiTaskCallback<ListModel>, DialogInterface.OnClickListener {
    public TextView textView;
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.textView);
        listView = (ListView) findViewById(R.id.listview);

        new ApiAsyncTask<ListModel>("http://14.49.231.5/b.json", ListModel.class, this).execute();
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {

    }

    @Override
    public void run(ListModel result) {
        listView.setAdapter(new MyListViewAdapter(this, result.list));
        Toast.makeText(MainActivity.this, result.list[0], Toast.LENGTH_LONG).show();

    }
}
